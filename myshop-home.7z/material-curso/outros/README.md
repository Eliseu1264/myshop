


# Django 3 by Example
This is the code repository for [Django 3 by Example](https://djangobyexample.com/), written by [Antonio Melé](https://antoniomele.es/) and published by [Packt](https://www.packtpub.com/product/django-3-by-example-third-edition/9781838981952). It contains all the supporting project files necessary to work through the book from start to finish.

## :warning:  New edition available
Check out the source code for the latest edition of this book: [Django 4 by Example](https://github.com/PacktPublishing/Django-4-by-example/)
### Download a free PDF

 <i>If you have already purchased a print or Kindle version of this book, you can get a DRM-free PDF version at no cost.<br>Simply click on the link to claim your free PDF.</i>
<p align="center"> <a href="https://packt.link/free-ebook/9781838981952">https://packt.link/free-ebook/9781838981952 </a> </p>